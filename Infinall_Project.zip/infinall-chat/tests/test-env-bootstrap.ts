import dotenv from 'dotenv';
import path from 'path';

// Load .env.local if present
dotenv.config({ path: path.resolve(process.cwd(), '.env.local') });

// Set default test environment flags
process.env.NODE_ENV = process.env.NODE_ENV || 'test';
process.env.STORAGE_MODE = process.env.STORAGE_MODE || 'local';
process.env.AUTH_MODE = process.env.AUTH_MODE || 'dev';
